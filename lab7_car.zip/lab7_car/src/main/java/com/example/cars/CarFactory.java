package com.example.cars;

interface CarFactory {
    Car createSUV();
    Car createConvertible();
}
