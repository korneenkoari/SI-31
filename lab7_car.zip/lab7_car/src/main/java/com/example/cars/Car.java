package com.example.cars;

interface Car {
    void create();//метод создания автомобиля
}
