package com.example.cars;

 class Convertible implements Car {
     @Override
     public void create(){
         System.out.println("Creating  an Convertible");
     }
}
